# Modes and page kinds

## The four modes (pick from the surface, not the product)

- **Persuade:** the visitor decides and acts; design is the product. Landing pages, marketing, pricing. Full commitment: bold, distinct, a point of view. A tool's landing page is still Persuade.
- **Operate:** the visitor completes a task. App UI, dashboards, editors, admin, settings. Scanability, consistency and native expectations outrank expression. Brand lives in precise details; ambition shows as precision and restraint. Known patterns earn their place.
- **Read:** the visitor understands something. Docs, articles, guides, changelogs. Structure for comprehension first, then make the reading worth staying in.
- **Experience:** the visitor is inside the work. Portfolios, galleries, showcases. The artifact leads from the first viewport; the interface recedes.

A docs index is Read, not Persuade. A fashion house's documentation is Read.

## Company sites (Persuade): the kind of business decides

| Kind | Examples | Leads with |
|---|---|---|
| software / gaming | app, SaaS, AI, dev tool, fintech, game | the client's own product at true size; real product UI |
| tech product | hardware, drone, keyboard | the device, big; effects allowed |
| product | chair, bike, coffee beans | photographs of the product, a different picture each section |
| service | clinic, law firm, agency, trade | the people, the rooms, the work |
| place | cafe, bakery, guesthouse, shop, gym | photographs (many), visit info on screen two |

Effects, shader scenes, loops and dark hero grounds only for software, gaming and tech. A local cafe or bakery gets photographs, flat color, type and one dealt moment.

A maker that also opens its door (ceramics studio, bakery with web shop) is a place.

## Page plan

- Name what a visitor comes to do (subscribe, book, visit, buy, try, hire) and build the page from where real sites in that category put the action and what they end with. Never a default run of figures, steps and an email band.
- Six to nine sections including hero and footer (five on a thin prompt), ~450 visible words at most. Each section is a piece of the category's own content in a composition with mass.
- One section per screen at 1440×900, one or two screens tall. No second heading peeking in at the fold.
- Hero: headline ≤7 words, one sentence ≤12 words, one or two actions. The hero is the first screen only.
- Signature: the one thing a visitor would remember, shown on the first screen (the photograph that is the place, the product doing its one job, a price set huge because it is the offer). A number drawn as marks is a device, not a signature.
- Deal variety: do not use the same composition twice; one contrasting ground; no fact stated twice.

## Components and app screens

A prompt naming one element ("just the card") is component scope: build that element, in the project's system, with all states. A screen someone works in is Operate: density, keyboard, empty/error/loading states, consistency over novelty.
