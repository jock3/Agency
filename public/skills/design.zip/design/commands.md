# Commands

Run the one the user names or clearly implies. Ask once if two fit. Inspect the target and the incumbent look before editing. Each ends with a review (`review.md`).

| Command | Does |
|---|---|
| **shape** | Plan UX/UI before code: users, job, flow, content, states. Output a short brief, no code. |
| **critique** | UX design review with heuristic scoring. Judge hierarchy, clarity, emotional fit, and generic-ness against `floor.md`. Report findings worst first, each with a fix. No edits unless asked. |
| **audit** | Technical checks: accessibility (contrast, focus, labels, landmarks), performance, responsive, reduced motion. Report only, with file:line. |
| **polish** | Final pass before shipping: alignment, spacing rhythm, states, copy, consistency. Preserves identity. |
| **bolder** | Amplify a safe or bland design: scale, contrast, a stronger type voice, one committed idea. |
| **quieter** | Tone down an aggressive or overstimulating design: fewer effects, calmer color, more space. |
| **distill** | Strip to essence. Remove sections, words and decoration that do not serve the one action. |
| **typeset** | Fix type hierarchy, faces, scale, measure, weights. |
| **layout** | Fix spacing, rhythm, alignment, visual hierarchy, grid. |
| **colorize** | Add strategic color to a flat UI: one anchor, tinted neutrals, accessible pairs. |
| **animate** | Add one purposeful motion moment plus responsive micro-interactions. Respect reduced motion. |
| **delight** | Add personality in small, earned touches. Never at the cost of clarity. |
| **clarify** | Improve UX copy, labels and error messages. |
| **harden** | Production readiness: errors, empty states, long text, i18n, slow network, edge cases. |
| **adapt** | Rework for other devices and sizes; check 390, 768, 1024, 1440. |
| **onboard** | Design first-run flows, empty states and activation. |
| **extract** | Pull repeated values into tokens and shared components. |
| **redesign** | Keep content and function; replace the visual world entirely (see `SKILL.md` rule 2). |

Defaults: never run a command the user did not ask for. With no argument, say what you see and offer the two or three commands that fit.
