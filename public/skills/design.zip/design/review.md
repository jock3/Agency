# Review

Runs only on request or before declaring a UI build done. Nothing here runs automatically; no hooks.

## Procedure

1. **Serve or open the page.** Dev server URL, or `file://` for static HTML.
2. **Batch the capture, one pass.** Using Playwright (CLI via `playwright-cli`, or the Playwright MCP / `qa-engineer` agent if available), take full-page screenshots at **1440×900, 1024×768, 768×1024 and 390×844**, plus a reduced-motion run. Look at all of them before fixing anything.
3. **Check against `floor.md`**, in this order:
   - Fold: hero headline, sentence and action visible at 1280×800.
   - No horizontal scroll at any width; nothing overflowing or clipped.
   - Every visual renders (no empty grounds or broken images) at every size.
   - Contrast, focus-visible (tab through the page), hover/active states.
   - Type: measure, scale, no all-caps labels, no single accented word in a heading.
   - Motion: one authored moment, reduced-motion fallback works, content visible without JS.
   - Facts: nothing invented; stand-ins clearly slots.
   - Generic-ness: would a neighbouring prompt give this same page? Name the tell if yes.
4. **Fix in one batch**, then recapture once. At most one confirming round.
5. **Report plainly:** what was checked, what failed, what was fixed, what was not checked. Never claim a pass that was not run.

## Verdict words

`ship` · `fix` (small issues listed) · `rebuild` (the direction itself is generic or broken) · `recapture` (screenshots unusable).

## If Playwright is unavailable

Say so, review from the code against `floor.md`, and mark the report "not visually verified".
