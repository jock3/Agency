# Tables

Read before building or restyling a data table, list view, comparison table or pricing grid. Tables are Operate-mode surfaces (`modes.md`): density and scannability beat decoration. The project's own table component wins; restyle it, do not replace it.

## First: is it a table?

- Rows of the same kind of thing with comparable attributes → table.
- Fewer than three columns, or each row is read on its own → list or cards.
- Comparing values is the point (trend, share, ranking) → a chart (`dataviz` skill or `diagrams/`), maybe with the table under it.
- Cross-tabulated values where colour shows size → heatmap (`diagrams/references/type-heatmap.md`).

## Columns

- Order by what the reader does: the identifying column first (name, campaign, client), then the values they compare, actions last.
- Hide or move rarely used columns behind a "Visa fler kolumner" toggle before you shrink everything.
- Headers in plain words, sentence case, no caps-lock. Put the unit in the header (`Budget (kr)`), not in every cell.
- Fixed widths for short codes, dates and numbers; the text column gets the rest.

## Alignment and numbers

- Text left. Numbers right, with `font-variant-numeric: tabular-nums` so digits line up. Header aligns with its column.
- Swedish formats: `12 500 kr` (non-breaking space as thousands separator, unit after), `2026-11-20` or `20 nov 2026` used the same way throughout, decimals with comma (`3,5 %`). Use `Intl.NumberFormat('sv-SE')` and `Intl.DateTimeFormat('sv-SE')`, not hand-made formatting.
- Same number of decimals down a column. Show the sign (`+`/`−`) on changes, and never rely on colour alone for good/bad.
- Empty value: an en dash `–` in muted colour, not `0`, `null` or blank (0 and "missing" mean different things).

## Density and rhythm

- Row height 40–48 px for normal use, 32–36 px for dense admin views; one height per table.
- Separate rows with a thin divider or a very light zebra stripe, not both. No vertical lines unless columns are hard to tell apart.
- Cell padding horizontal 12–16 px; the first and last cell line up with the content edge above the table.
- Highlight the hovered row lightly; the selected row clearly, with more than a colour change (checkbox, left border).

## Behaviour

- Sticky header for tables taller than the screen; sticky first column if it scrolls sideways.
- Sorting: clickable header with an arrow showing direction, `aria-sort` on the sorted column, default sort stated or obvious.
- Long text: truncate with an ellipsis in one line and show the full value on hover/focus (`title` is not enough for keyboard users).
- Many rows: pagination or "Visa fler" for business tables; virtual scrolling only above about 1 000 rows.
- Totals row at the bottom, visually distinct (bolder, top border), aligned with its columns.
- Actions: one primary action per row visible; the rest in a "⋯" menu with an accessible name.

## States

- Loading: skeleton rows in the table's real shape, not a spinner over an empty box.
- Empty: one sentence on why it is empty and the action to fill it ("Inga kampanjer än. Skapa den första.").
- Filtered to nothing: say which filter caused it and offer "Rensa filter".
- Error: what went wrong in plain words and a retry button; keep the old data visible if there is any.

## Small screens

Under about 640 px pick one: keep the 2–3 key columns and hide the rest behind a row tap, or turn each row into a card with label/value pairs. Never squeeze ten columns into a phone width; a sideways-scrolling table is fine only with a sticky first column and a visible scroll hint.

## Accessibility

Real `<table>`, `<thead>`, `<th scope="col">` (and `scope="row"` for the identifying cell) unless the project's grid component handles roles. A `<caption>` or `aria-label` naming the table. Interactive cells reachable by keyboard. Contrast for muted text and dividers per `floor.md`. Check with the `accessibility` skill.
