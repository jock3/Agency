# Floor

Binds every output. Where sources disagreed, the stricter, checkable rule is kept. Only the user's own words beat it, and that includes a project's own DESIGN.md (note the deviation, do not rewrite it).

## Hard rules (never waived)

1. Every color and font goes through a token declared at `:root` (or a theme block). No literal colors or `font-family` past the token block.
2. Never `transition: all`. Never animate `width`, `height`, `top`, `left`. Animate `transform` and `opacity` (plus blur, clip-path, mask when smooth).
3. Never one italic/bold/colored word inside an otherwise plain heading.
4. `overflow-x: clip` on `html` and `body`. Never `hidden`, never `100vw`.
5. Image grid tracks use `minmax(0, 1fr)`; display heads carry `overflow-wrap: break-word; min-width: 0`.
6. Every interactive element has an instant `:focus-visible` state.
7. Every animation has a `prefers-reduced-motion: reduce` fallback. Content is visible with scripting off.
8. No invented metric, testimonial, logo wall, case-study count, address, phone or registration number.
9. No eyebrow or kicker above a heading. No labels in tracked capitals or small caps: labels, captions, table heads, tags and nav links use the body face, a step smaller, sentence case, untracked.
10. No middle-dot-joined meta strings (`A · B · C`), no arrows glued to link text, no decorative status dots, no `WORD — fragment` labels.
11. No purple-to-blue gradient, no card inside a card, no emoji or unicode glyph as an icon, no hand-drawn browser/OS window, no gradient text.
12. Hero headline, one sentence and the primary action are visible at 1280×800 without scrolling.
13. About 80 words on any one screen; hero text is headline + one sentence + actions.
14. Container is capped and centred: at 1920 the gutters grow, the measure and grids do not.
15. No caption or description under an image or visual. Licence credits go in one footer line.
16. Equal left and right content edges.

## Defaults to refuse (the brief's own words can earn them back)

- Same-size icon + heading + text cards as the page structure. Cards are the lazy container.
- The hero-metric template: big number, small label, supporting stats, accent.
- Section numbers (01 / 02 / 03) unless the content is truly a sequence.
- A modal for a task that needs neither interruption nor protected focus.
- Glass/blur as decoration. A one-sided colored bar on a rounded box. Hard offset shadows outside a real neobrutalist world. Zero-offset colored halos.
- Sparklines, progress rings or soft rounded rectangles standing in for content.
- Monospace as a "technical" costume (use it for code, data, measurement).
- A system display face (Impact, Arial Black, platform sans) as the display voice. Source a real face whose character fits.
- Geometric masks standing in for a photographic subject's outline.
- Light or dark chosen by category. Choose from the use scene: who, where, under what light.
- The generated-page clusters: warm cream + high-contrast serif + terracotta accent (≈#D97757); near-black + one acid-green/vermilion accent; hairline-ruled broadsheet with zero radius; identical rounded SaaS cards with one soft grey shadow; tinted near-black (#0B0B0B/#111) standing in for black; one border radius everywhere.
- Fade-and-slide-up on every section, hover lift on every card, timed tabs, carousels, tilt.

## Type, space, color

- Body ≥16px, measure 65–75ch (serif may run slightly longer, with more line-height). Display max ~6rem, tracking floor −0.04em, balanced headings. Heads one weight and one color.
- Two families at most (three with one outlier role). If two, make them clearly distinct.
- Contrast: body/placeholder ≥4.5:1, large text ≥3:1. On colored surfaces tint secondary text from that hue, never gray.
- Spacing: tight groups, generous separation, more space above a heading than below. One primary button style, one container width, one column gap below the hero, one radius per nesting level.
- Shadows carry an offset and a soft blur.

## Motion

One authored moment per page (two on a long page), not scattered effects. Exponential ease-out from an already-visible default. Motion that answers a user action (open, expand, confirm) is welcome. Hero may enter once on load.

## States and surfaces

- Eight states on every control: default, hover, focus-visible, active, disabled, loading, error, empty where relevant.
- Theme the parts nobody draws: text selection, caret, scrollbars, focus rings, underline offset, tabular numerals. This is the cheapest signal a page was built, not assembled.
- Copy in the product's own language. Controls name their action. Errors name the problem and the recovery. Plain copy with a voice; no filler.
- Icons: a real library or authored SVG, one consistent stroke and weight.

## Imagery

Show the real thing: the user's pictures, screenshots of the real product, or clearly marked stand-in slots the user's files replace. Never a stock-site URL, a drawn illustration standing in for a photo, an empty wash, or a row of counting marks. Photographs take at most a third of the page below the hero, never two photograph-led sections in a row.

## Loaded symbols

Never use emblems tied to militarism, supremacy or hate movements as decoration (motifs, badges, ornament). Use the subject world's neutral forms instead.
