---
name: design
description: "One design skill for building, redesigning, critiquing and polishing frontends: websites, landing pages, dashboards, app UI, components. Also makes diagrams and charts (architecture, flowchart, sequence, Gantt, bar, heatmap, Sankey and 40+ more) as HTML/SVG/PNG. Use whenever the user asks for UI work, says a page looks generic/templated/AI-made, or says 'design', 'granska' (UI/design), 'critique', 'polish', 'diagram', 'flödesschema', 'arkitekturbild'. Not for code review (use code)."
argument-hint: "[build | critique | polish | review | diagram] [target]"
---

# design

One skill, four steps: **brief → direction → build → review.** It merges frontend-design, Impeccable, Hallmark and Taste (see `SOURCES.md`). Where they disagreed, the Hallmark-style hard floor won (`floor.md`).

Load only what the step needs. Do not read every file up front.

## Rules that override everything

1. **The brief wins.** If the user pins a look, era, font or palette, follow it, even when it matches a default in `floor.md`.
2. **Refinement preserves, redesign replaces.** A small tweak keeps the incumbent identity, copy and structure. A redesign keeps content, function and facts, and treats the old look as the thing to leave behind. Never half-polish a discarded look.
3. **Never invent facts.** No made-up metrics, testimonials, logos, customer counts, addresses or phone numbers. Missing material becomes a visible stand-in slot.
4. **Milou apps start from `milou/milou.md`.** For anything that should look like milou.se or Agency, read it before the brief step. It holds the tokens, components, contrast limits and a refresh script.
5. **The project's own system beats the floor.** If a DESIGN.md, CLAUDE.md or token file already fixes a pattern (e.g. caps labels), keep it and note the deviation from `floor.md` instead of "fixing" it. Read existing tokens, fonts, CSS and framework first. Existing stylesheets are append-only.
6. **Finish the job.** Complete, responsive, with real states. Only assets the user must supply may be missing.

## 1. Brief (ask once, then go)

Read the project first (DESIGN.md, tokens, `package.json`, fonts, existing pages). Then, in one short message, settle only what is still unknown:

- **Material:** what real content can the page show (screenshots, photos, numbers, quotes)?
- **Audience and the one action** the surface should drive.
- **Tone:** pick an extreme (editorial, brutalist, soft, utilitarian, luxury, playful, technical, austere). "Clean and modern" is not a tone.

If the prompt answers these, or the user says "go ahead", infer, state the inferences in one line and build. Facts are never inferred.

## 2. Direction

Read `modes.md`. Pick the **mode** from the surface (Persuade / Operate / Read / Experience), not from the product. Pick the **kind of business** if it is a company site. Then write a compact plan before any code:

- Color: 4–6 named hex values. Type: faces and roles. Layout: one-sentence concept (+ ASCII wireframe if useful). Principles: the one memorable thing.
- Review the plan against the brief: would a neighbouring prompt produce the same plan? If yes, change one decision and say which.

Spend boldness in one place. Everything around it stays quiet.

## 3. Build

Read `floor.md` immediately before the first UI edit; for a data table also `tables.md`. Build the hero (or first screen) first, check it, then the rest. One idea per screen, set big. Take commands from `commands.md` when the user asks for a specific move (critique, polish, bolder, quieter, typeset, layout, animate, harden…).

## 4. Review

When asked to review (or before calling a build done), read `review.md` and run it: real screenshots at real sizes via Playwright, then the floor checklist. Fix what one look shows before looking again. Report outcomes plainly; never claim a pass that was not checked.

## Diagrams (separate route)

When the ask is a diagram or chart (architecture, flow, sequence, timeline, Gantt, bar, heatmap, Sankey, org chart, import from Mermaid/draw.io/Excalidraw…), skip steps 1–3 above and read `diagrams/GUIDE.md`. It picks the diagram type from `diagrams/references/` and outputs self-contained HTML/SVG/PNG. Do not read the 70 reference files up front, only the one type file you need.

- **Colors and fonts come from this skill's direction, not from a second interview.** If the project already has tokens or you have settled a palette in step 2, fill `diagrams/references/style-guide.md` from those and skip the "first diagram" question in GUIDE.md §0. Ask only when nothing is settled.
- `floor.md` still applies to any page the diagram sits on. The diagram's own density rules (GUIDE.md §1) apply inside the diagram.
- Paths in GUIDE.md (`references/`, `assets/`, `scripts/`) are relative to `diagrams/`.
- Tables are not a diagram type here. Building or restyling a data table: read `tables.md`. Cross-tabulated data with colored cells: the heatmap type.

## Files

- `milou/` — Milou design system for new apps: `milou.md` (guide, contrast limits), `tailwind.milou.ts`, `milou.css`, `PageHeader.tsx`, `Ticker.tsx`, `refresh.sh` (compares milou.se against the saved snapshot)
- `diagrams/` — diagram-design v2.6 bundled (GUIDE.md, `references/`, `scripts/`, `assets/`)
- `tables.md` — data tables: when to use, columns, Swedish number/date formats, density, states, mobile, a11y
- `floor.md` — hard rules, defaults to avoid, quality checks
- `modes.md` — four modes, business kinds, page-plan guidance
- `commands.md` — critique, polish, bolder, quieter, typeset, layout, animate, harden, adapt
- `review.md` — Playwright review procedure
- `SOURCES.md`, `licenses/` — credits and license texts
