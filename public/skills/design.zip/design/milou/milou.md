# Milou: designsystem för nya appar

Läs den här filen innan du bygger eller ändrar något som ska se ut som Milou (milou.se, Agency, nya interna appar). Projektets egen DESIGN.md går före.

Källa: milou.se, senast jämförd 2026-11-20. Referensbygge: `~/Agency` (jock3/Agency). Hela måttsamlingen står i `milou-grafiskt-uttryck.md` i den här mappen.

## Innan du börjar

1. Kör `bash ~/.claude/skills/design/milou/refresh.sh`. Skriver den "Inga ändringar" är resurserna aktuella. Annars: uppdatera `milou-grafiskt-uttryck.md`, `tailwind.milou.ts` och `milou.css`, och kör `refresh.sh --save`.
2. Skärmbilder av sajten: `node` + `playwright-core` (finns i `~/stc-bokare/node_modules`). Sidor att titta på: `/`, `/vad-vi-gor/`, `/creative-digital/`, `/marketing-partner/`, `/vad-vi-gor/ai-solutions/`. Scrolla sidan stegvis före bilden, annars syns inte sektionerna som animeras in.

## Det som ska kopieras in i en ny app

| Fil | Vad |
|---|---|
| `tailwind.milou.ts` | Färger (milou/red, gray, peach, beige, blush, plum, teal), plattskuggor, gradient, raka hörn |
| `milou.css` | Klasser: `milou-plate`, `milou-kicker`, `milou-display`, `milou-display-sm`, `milou-btn` (+ `-peach`, `-beige`, `-ghost`, `-outline`, `-red`), `milou-num`, `milou-ticker` |
| `PageHeader.tsx` | Mörkt sidhuvud med kicker, rubrik, ingress, knapp |
| `Ticker.tsx` | Rullande remsa, pausbar, `aria-hidden` på kopian |

Typsnitt: Komet Regular finns som fil (`Agency/public/fonts/Komet-Regular.otf`). Fet text sätts i REM via `next/font/google` (variabeln `--font-rem`), eftersom fet Komet annars syntetiseras. Milous Adobe-kit (`ifc4ywc`) ger riktiga vikter men får inte användas utan Milous OK.

## Mönster från milou.se

- **Sidans gång:** mörk hero (#1C1C1C) → rullande remsa i röd gradient → mörk sektion → ljusgrå sektion med kort → mörklila sektion → röd gradient-CTA. Helbreddsband direkt efter varandra. Innehåll max 1112 px, sidopadding 1.5 rem mobil och 2 rem desktop, sektionsluft 96 px.
- **Hero:** kicker (versaler, 14 px, spärrning 0,2em, persika), stor rubrik i två tonlägen (första meningen vit, andra i blush/persika), ingress i vit 90 %, knappar (persika + kantad), rund stämpel med text runt kanten och ett nummer.
- **Kort på ljust:** vit yta, solid skuggplatta utan oskärpa som roterar per kort (ljusröd, beige, persika). Raka hörn.
- **Röda pilrutor** (56 px) under korten. Rödgradient endast i remsa, CTA och som liten accent.
- **Case-kort på mörkt:** enda stället med rundade hörn (1 rem), lyfter 4 px med röd glöd vid hover.

## Hårda regler (kontrast och tillgänglighet)

Uppmätta med axe och `lib/a11y/contrast`-beräkning i Agency:

| Par | Kontrast | Slutsats |
|---|---|---|
| Röd gradient (#E60330 till #9D3A7C) på #1C1C1C | 3,6 till 2,7:1 | **Aldrig gradienttext på mörk botten.** Använd persika (10,9:1) eller blush (8,4:1). Gradienttext bara på ljus botten. |
| Persika-knapp med #2B2B2B-text | 9,0:1 | OK. Vit text på persika är 1,6:1, använd aldrig. |
| Vit på #E60330 | 4,75:1 | OK för 14 px fet text och uppåt |
| Beige på #E60330 | 3,76:1 | Bara stor text |
| #8F8F8F (gray-500) och #AAAAAA (gray-400) på ljus botten | 3,2 och 2,3:1 | **Underkänt för text.** Använd gray-600 (#6C6C6C, 4,7:1 på #F2F2F2) eller mörkare. På gray-100 (#EAEAEA) krävs gray-700. gray-400 duger bara på mörk botten (7,3:1). |
| #931644 (kantad knapp) på vit | 8,6:1 | OK |

Övrigt: remsan måste kunna pausas och stå still vid `prefers-reduced-motion`. Kopian i slingan har `aria-hidden`. Fält har riktiga `<label for>`. Fokus: persikaring på mörkt, röd ring på ljust. Skuggplattorna kräver luft: gap minst lika stort som förskjutningen (≥ 56 px mellan kolumner, ≥ 80 px mellan rader) och inga `overflow-hidden`-föräldrar. Nya fakta hittas aldrig på: remsan visar bara verkliga verktygs- eller tjänstenamn.

## Portningsfällor

- Sätt inte om `borderRadius` i Tailwind-konfigen. Alla `rounded-*` är nollade med avsikt. Rundning på case-kort görs lokalt med `rounded-[1rem]`.
- `.mc-page-ai-display--xl` på sajten har `max-width: min(845px, 100vw − 314px)`. Det blir 76 px på mobil om inte sajtens mediaregel (max 1023 px: 852 px) följs. Kopiera inte klassen rakt av.
- Tailwind-grå är överskrivna med sajtens neutrala grå. Förlita dig inte på Tailwinds standardgrå.
- Hub-sidor ska bygga korten ur samma lista som menyn, annars visar menyn och startsidan olika verktyg.

## Så testas ett bygge

1. `npx tsc --noEmit`, tester och `npm run build`.
2. Skärmbilder vid 1440 och 390 px före och efter, för varje sida som rörs.
3. axe (`wcag2a, wcag2aa, wcag21aa, wcag22aa`) på varje sida. Skripten som användes finns att skriva om på två minuter: logga in med testkonto, `page.addScriptTag(axe.min.js)`, `axe.run`. Data-styrda färger (användarvalda gruppfärger) kan ge kontrastfel som inte är designfel; rapportera dem separat.
4. Efter push: kontrollera deploy-status och titta på live-sidan.
