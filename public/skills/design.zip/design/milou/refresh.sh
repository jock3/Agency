#!/bin/bash
# Hämtar milou.se:s färgvariabler, skuggor och typsnittsvikter och jämför med sparad ögonblicksbild.
# Körs före varje nytt Milou-bygge:  bash ~/.claude/skills/design/milou/refresh.sh
# Ändringar: uppdatera milou-grafiskt-uttryck.md, tailwind.milou.ts och milou.css, kör sedan med --save.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
CSS_URL=$(curl -sL https://milou.se/ | grep -oE 'https://milou\.se/wp-content/themes/milou\.se/dist/tailwind\.[^"]+\.css' | head -1)
[ -n "$CSS_URL" ] || { echo "Hittade ingen stilmall på milou.se"; exit 1; }
curl -sL "$CSS_URL" -o "$TMP/site.css"
{
  echo "# stilmall: $(basename "$CSS_URL")"
  echo "## färger"; grep -oE '\-\-(color|gradient)-[a-z0-9-]+:[^;}]+' "$TMP/site.css" | grep -v 'var(' | sort -u
  echo "## skuggor"; grep -oE 'box-shadow:[^;}]+' "$TMP/site.css" | grep -vE 'var\(--tw|none' | sort -u
  echo "## komponenter (mc-page-ai)"; grep -oE '\.mc-page-ai[a-z0-9_-]*' "$TMP/site.css" | sort -u
  echo "## typsnittsvikter (Adobe Fonts-kit ifc4ywc)"; curl -sL https://use.typekit.net/ifc4ywc.css | grep -oE 'font-weight:[0-9]+' | sort -u | tr '\n' ' '; echo
} > "$TMP/now.txt"
if [ "${1:-}" = "--save" ]; then cp "$TMP/now.txt" "$DIR/tokens.snapshot.txt"; echo "Ögonblicksbild sparad."; exit 0; fi
if [ ! -f "$DIR/tokens.snapshot.txt" ]; then echo "Ingen ögonblicksbild än. Kör med --save."; exit 1; fi
# Filnamnets hash ändras vid varje bygge på sajten, så den raden jämförs inte.
if diff <(grep -v '^# stilmall' "$DIR/tokens.snapshot.txt") <(grep -v '^# stilmall' "$TMP/now.txt"); then
  echo "Inga ändringar mot ögonblicksbilden ($(head -1 "$DIR/tokens.snapshot.txt"))."
else
  echo; echo "^ Skillnader mot sparad version. Uppdatera resurserna och kör med --save."; exit 2
fi
