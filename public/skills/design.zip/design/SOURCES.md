# Sources

This skill is an original distillation. It does not copy the sources verbatim; it merges their ideas into one workflow. License texts are in `licenses/`.

| Source | Author | License | What was taken |
|---|---|---|---|
| Impeccable (pbakaus/impeccable) | Paul Bakaus | Apache 2.0 | Four modes (Persuade/Operate/Read/Experience), command set, "brief wins / refinement preserves / redesign replaces", craft-floor checks, loaded-symbols rule |
| Hallmark (Nutlope/hallmark) | Hallmark contributors, Together AI | MIT | The hard floor (tokens, motion, focus, no invented facts, no eyebrows), hero and word budgets, the ask-once brief, "signature" and mirror test |
| tasteskill (Leonxlnx/taste-skill) | Leonxlnx | MIT | House rules (no captions, one section per screen, equal edges), business-kind table, effects only for tech |
| frontend-design | Anthropic | see `licenses/frontend-design-LICENSE.txt` | Plan-then-review process, default-trait calibration, restraint |

| diagram-design (cathrynlavery/diagram-design) v2.6 | Cathryn Lavery | MIT | Bundled unmodified in `diagrams/` (SKILL.md renamed `GUIDE.md` so it is not loaded as a separate skill). Licenses: `licenses/diagram-design-LICENSE.txt`, `licenses/diagram-design-THIRD_PARTY_LICENSES.md` |

## Conflict decisions

Hard, checkable rules (Hallmark floor) beat softer judgement (Impeccable) and company-site strictness (Taste). Taste's one-section-per-screen and no-caption rules apply to Persuade pages only. Operate surfaces follow Impeccable's density and consistency guidance.

## Left out on purpose

Impeccable's downloaded launcher binary and edit-hook; Taste's Stop hook, 39 MB asset library and Node gate; Hallmark's theme dealer, sloplint and capture scripts. Review runs through Playwright on request instead.
