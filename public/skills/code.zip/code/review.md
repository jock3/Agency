# Review: does the change hold?

Review like the person who gets called when it breaks. Order: correct → safe → holds at the real load → tested → fast → lean. This is a report; it changes no code until Gustav says which findings to fix.

## 1. Understand first

- Target: what Gustav names (uncommitted changes, a branch, a PR, a commit, files). Nothing named: uncommitted changes, else the last commit.
- Read the diff, then the code it touches: callers of every changed function, what they call, the tests.
- Find the spec: the request in this conversation, an issue referenced in the commits, a spec file in `docs/`. If there is none, say so.
- Find the expected load (one person, a team, public users) from README or deploy config, and say which you assumed.
- Large diff or high stakes: run `/code-review` or the `code-reviewer` agent in parallel and fold its verified findings in. Security-sensitive (auth, payments, uploads, user input): add `/security-review` or the `security-auditor` agent.

## 2. Look for

1. **Bug:** wrong result, crash, missed edge case, a caller broken by the change, a fix in one caller while the shared code stays broken.
2. **Risk:** injection, secrets in client code or the repo, missing server-side auth or row-level security, swallowed errors, writes without a transaction.
3. **Load:** fine for one user, wrong for many: check-then-write races, a query per item, lists that only grow.
4. **Missing test:** risky new logic with no test that fails when it breaks. One good test, not coverage.
5. **Spec:** asked for but missing or wrong; built but not asked for (scope creep). Kept separate from code quality so one cannot hide the other.
6. **Lean:** dead code, unused options, an abstraction with one use, a helper the repo already has, a new dependency for a few lines.

## 3. Prove each finding before reporting

Every finding needs a concrete case: "this input leads to this wrong result". Re-read the lines and confirm the caller exists, the value can be empty, the code is unused. No case, no finding. A marked `shortcut:` comment is a decision, not a finding, unless the real load already crosses it. No taste, no "consider".

## 4. Report (plain Swedish, for someone who does not read code)

Start with **Vad ändringen gör:** in two or three sentences.

Then numbered findings across three groups, skip empty groups:
- **Måste fixas:** bug, security, data loss, breaks at the expected load, spec not met.
- **Bör fixas:** risky code without a test, real slowness, duplication, scope creep.
- **Bra att ha:** small speed-ups, shorter forms.

Each finding:
1. **Rubrik i vardagsord** (`fil:rad`)
   - **Vad det är:** what this part does, one sentence.
   - **Problemet:** what goes wrong, with the concrete case.
   - **Fix:** the smallest fix, preferably one that removes code.
   - **Om vi skippar det:** what Gustav or the app's users would notice.

End with:
- `Bedömning: Klart att skicka.` or `Bedömning: fixa 1 och 3 först.`
- `Kan kortas: -N rader.` when lean findings exist.
- `Inte kollat:` one line, if something that mattered could not be checked.

Nothing found: **Vad ändringen gör:**, then `Ser bra ut. Klart att skicka.` and one line on what was checked.

## QA (the running app)

For anything with a UI or user flow: after code review, check it running. `/run` or Playwright screenshots at real sizes, or the `qa-engineer` agent for a full click-through. UI looks: `design-reviewer` agent or the `design` skill's review. Accessibility: the `accessibility` skill. Report what was clicked through and what was not.
