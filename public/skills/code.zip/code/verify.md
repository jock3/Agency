# Verify: evidence before claims

No "done", "fixed", "works" or "passes" without output from this session that shows it.

## The gate

1. Which command or action proves the claim? (test suite, typecheck, build, a request to the dev server, a Playwright screenshot, opening the page)
2. Run it in full, now. An earlier run does not count.
3. Read the output: exit code, number of failures, warnings that matter.
4. Output confirms the claim → state it with the evidence. It does not → state the real status with the evidence.

| Claim | Needs | Not enough |
|---|---|---|
| Tests pass | Test run with 0 failures | "Should pass", a run before the last edit |
| Builds | Build exit 0 | Lint passing |
| Bug fixed | The original symptom no longer happens | The code was changed |
| Test protects the fix | Saw it fail without the fix, pass with it | It passed once |
| Agent finished | The diff shows the change | The agent said "success" |
| Feature works | Used it in the running app (`/run`, Playwright, `qa-engineer`) | Unit tests green |
| Request met | Each part of the request checked off | Tests green |

## Tests: proportional, not ceremonial

- New non-trivial logic (a branch, a parser, money, security, data writes, a bug fix) gets one small test that fails if it breaks. Bug fix: write the test that reproduces the bug first, watch it fail, then fix.
- Trivial changes need no new test, but the existing suite must still pass.
- Run the project's whole suite, not just your file, before saying done.
- No test setup in the project? A short self-check (assert or a script run) is enough; say so.

## Stop signs

"Should work", "probably", "looks right", satisfaction before a run, about to commit or push without a run, trusting a subagent report without the diff. Any of these: run the check first.

## Reporting to Gustav

Plain Swedish. What was checked and how (a screenshot or the one line of output that matters), what was not checked and why. Never claim a pass that was not run.
