# Deploy, rollback and projects without git

Read before pushing, deploying, or editing a project that has no git.

## Before any edit: can this be undone?

- Run `git status` in the project. **No git repo:** copy the files you will touch to `~/.agents/backup-<project>-<date>/` first (or `git init` + first commit if Gustav agrees), and say where the backup is. Never edit a git-less project without one of the two.
- Uncommitted changes from someone else in a git repo: do not mix them into your commit. Ask, or commit only your own files.

## Know how the project deploys (read, don't guess)

Look in the project's CLAUDE.md, README, `vercel.json`, `.github/workflows/`, `package.json` scripts and memory. Typical patterns in Gustav's projects:

| Pattern | What it means | Watch out |
|---|---|---|
| Push to `main` → Vercel auto-deploys | Every push is a release | Push only after verify passes; then check the deploy finished and look at the live page |
| `vercel --prod` from a folder, no git integration | Uploads the working tree, not a commit | Uncommitted or experimental files go live too. Commit first so live = a known commit; note the commit in the report |
| No deploy (local tool) | Nothing goes live | Still back up before editing |

If a project's own rule says "push straight to main", follow it without asking. Database migrations that destroy data still need an OK (`supabase.md`).

## Release steps

1. Verify locally (`verify.md`): typecheck, build, tests, the app running.
2. Commit with a message that says what changed and why. One logical change per commit, so it can be reverted alone.
3. Push or deploy the way the project does it.
4. Check the deploy: build status (Vercel dashboard or `vercel ls`/`vercel inspect`), then open the live URL and click the changed flow. A green build is not a working site.
5. Tell Gustav in plain Swedish: what is live now, the commit, what was checked on the live site, what was not.

## Rollback

- Git + auto-deploy: `git revert <commit>` and push. Never force-push or rewrite `main`.
- Vercel: promote the previous deployment (`vercel rollback` or the dashboard) when a fix will take longer than a few minutes.
- Database: a migration is not undone by reverting code. Write a new migration that restores the previous state; if data was deleted, it needs a backup restore. That is why destructive changes need an OK first.
- Say which of these was used and whether users may have seen the broken version.

## Secrets

- Keys live in `.env*` files that are gitignored, and in Vercel/Supabase settings. Never in source, commits, logs or reports. Show at most the first four characters.
- A key that leaked (committed, in client code, in a screenshot): tell Gustav to rotate it now. Removing it from the code does not un-leak it; git history keeps it. After rotation, update every place it is used (local `.env`, Vercel env, other apps sharing it) and redeploy.
