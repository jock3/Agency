# Sources

An original distillation, built 2026-11-20. Ideas are merged into one flow and rewritten; only `ship/` and `supabase/` are copied verbatim. License texts are in `licenses/`.

| Source | Author | License | What was taken |
|---|---|---|---|
| Superpowers (obra/superpowers) | Jesse Vincent | MIT | Evidence-before-claims gate (`verify.md`), root-cause phases and the 3-failed-fixes stop (`debug.md`), plan → build → verify → review flow |
| andrej-karpathy-skills (forrestchang) | forrestchang, after Andrej Karpathy's observations | MIT (stated in README, no LICENSE file; see `licenses/karpathy-skills-README-license.txt`) | Think before coding, simplicity first, surgical changes, goal-driven verification. Rewritten into `floor.md` and the global CLAUDE.md block |
| Ponytail (DietrichGebert/ponytail) | DietrichGebert | MIT | Smallest-complete-change ladder, `shortcut:` comments, "never cut" list (`floor.md`); review order, proof-per-finding and the four-part finding format (`review.md`, translated to Swedish) |
| skills (mattpocock/skills) | Matt Pocock | MIT | Feedback-loop-first debugging and tagged debug logs (`debug.md`); spec vs standards kept as separate review axes (`review.md`) |
| agent-skills (supabase/agent-skills): `supabase` v0.1.2 and `supabase-postgres-best-practices` v1.1.1 | Supabase | MIT | Bundled unmodified in `supabase/` and `supabase/postgres/` (SKILL.md renamed `GUIDE.md`). `supabase.md` adds Gustav's shared-project rules on top |
| Condom (murphyaidanbusiness-ux/condom) | murphmaxxing | MIT | Bundled unmodified in `ship/` (SKILL.md renamed `GUIDE.md` so it does not load as its own skill). Its own `VERIFICATION.md` says which legal quotes are unconfirmed |

## Conflict decisions

- **Tests:** Superpowers demands strict TDD for everything ("delete code written before the test"). Ponytail asks for one small test for non-trivial logic. Ponytail's proportional rule won; test-first is kept for bug fixes, where it pays most.
- **Gates:** Superpowers' brainstorming approval, design docs and plan files in `docs/superpowers/` were left out. Gustav does not read code; the gate is a plain-Swedish OK before big rebuilds, and the project's own CLAUDE.md can remove even that.
- **Review format:** Ponytail's plain-language format won over Pocock's raw two-report output, because Gustav reads the result. Pocock's spec/standards separation survives as its own finding group.
- **Law in `ship/`:** Condom's legal thresholds are US-heavy. Gustav's users are in Sweden/EU, so SKILL.md tells it to treat GDPR and EU cookie rules as applying from the first user.

`deploy.md` is written for this setup (Vercel auto-deploy from main, `vercel --prod` without git, git-less local tools); no external source.

## Left out on purpose

Superpowers' session hooks, worktree and subagent-driven-development skills; Ponytail's hooks, benchmarks and gain/debt commands; Pocock's issue-tracker setup and writing skills; Condom's `tools/check_quotes.py` (makes network calls; not needed to run the audit). Existing built-ins cover the rest: `/code-review`, `/simplify`, `/security-review`, agents `architect`, `code-reviewer`, `debugger`, `test-runner`, `test-engineer`, `qa-engineer`, `security-auditor`.
