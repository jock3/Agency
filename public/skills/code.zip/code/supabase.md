# Supabase and the database

Read this before any change that touches Supabase: tables, columns, RLS policies, grants, functions, triggers, auth, storage, keys, or a migration. The official guidance is bundled in `supabase/GUIDE.md` (Supabase's own security checklist, CLI and migration workflow) and `supabase/postgres/GUIDE.md` (Postgres rules, one file per rule in `supabase/postgres/references/`). Read the checklist in `supabase/GUIDE.md` §6 for any auth/RLS/view/function/storage change; open single Postgres rule files only when relevant.

## Gustav's setup (check memory for the current state)

- **Several apps share one Supabase project.** A change to a table, policy or function can break or open up another app. Before changing anything, list which apps read or write that table (grep every repo that uses the project ref) and say so in the plan.
- **Business-data tables have been world-open via the anon key** (`using (true)`), tracked in jock3/claude#4. Never add sensitive or personal data to a table that is still open, and do not make a new table open "for now".
- **The free tier pauses after about a week idle.** Empty results or connection errors right after a long break may mean the project is waking up, not that the code is wrong. Wait and re-run before debugging.
- **The project's own CLAUDE.md and migrations folder win** over anything here.

## Rules for every change

1. **New table → RLS on, plus a real policy.** Owner check like `(select auth.uid()) = user_id` (or the project's profile mapping), `TO authenticated`, and `WITH CHECK` on insert/update. `using (true)` is only for data that is truly public.
2. **Never put the service-role/secret key in the browser.** In Vite, any `VITE_` variable ships to the client; in Next.js, any `NEXT_PUBLIC_` variable. Server code and edge functions only.
3. **Never "fix" a permission error with `SECURITY DEFINER`** or by widening a policy. Find which policy or grant is missing.
4. **Views bypass RLS** unless created `with (security_invoker = true)`.
5. **Destructive changes need Gustav's explicit OK** before running: drop/rename table or column, delete rows, change a column type, tighten a policy that live apps rely on. Say in plain Swedish what stops working and for whom. This holds even in projects that push straight to prod.
6. **Migrations live in the repo.** Change via a migration file (follow the project's numbering) rather than ad-hoc SQL in the dashboard, so the change can be seen and repeated. If a quick SQL fix was run directly, write the matching migration in the same session.
7. **Tightening RLS: plan the order.** First make the app send an authenticated identity, deploy, check it works, then tighten the policy. The other order locks every user out.

## Verify (no "done" without this)

- Run the advisors after any schema change: MCP `get_advisors` (security and performance) or `supabase db advisors`. Fix new warnings or explain them.
- Prove the policy both ways: the owner sees and changes their row; another user, and the anon key, see nothing. A two-user SQL check or two browser sessions both count.
- Exercise the app flows that touch the table (sign-up, create, edit, delete) in the running app.
- Report in plain Swedish: which tables changed, who can now read or write what, which apps are affected, what was tested.
