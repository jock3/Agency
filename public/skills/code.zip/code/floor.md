# Floor: how to build

## Before the first edit

- Read the task and every place the change must reach: callers, tests, fixtures, config, exports, docs. That is the scope. Extra features are not.
- Check what the change could break for real users: data it could destroy or expose, callers that stop working.
- Unclear what is wanted? Stop and ask one specific question. Two plausible readings? Show both, do not pick silently.
- A simpler approach than the one asked for? Say so before building.

## Pick the smallest option that fully works

1. Does it need to exist at all? Skip options, flexibility and "for later" code nobody asked for. Name what you skipped in one line.
2. Does the codebase already have it (helper, component, pattern)? Use it the way the surrounding code does.
3. Standard library or platform feature? Use it, unless the project has its own.
4. An installed dependency? Use it. Never add a dependency for a few lines.
5. Otherwise the least code that works and reads at a glance.

## While editing

- Touch only what the task needs. Do not reformat, rename or "improve" neighbouring code. Match the existing style.
- Every changed line traces back to the request.
- Remove imports, variables and functions that your change made unused. Leave older dead code alone; mention it instead.
- Bug fix: find every caller of the function you touch, fix the root cause once in shared code, not in one caller.
- Moved or merged code keeps its error handling and validation.
- Between equal-sized options, take the one that is right on edge cases (empty, zero, last item, time zones, rounding).
- Comments only for the why the code cannot show, one line.
- A deliberate shortcut gets a comment: `shortcut: <the limit>, <when to upgrade>`.
- Lazy about the solution, never about finishing: callers, tests and fixtures the change breaks are part of the job.

## Never cut

Validation where untrusted input enters, error handling that prevents data loss, security checks (auth on the server, row-level security, secrets out of the browser), accessibility, anything the user asked for.

## Done looks like

A short diff, every part of the task reached, one test or self-check for new non-trivial logic, and a two-line note: what was skipped or not checked, and any risk Gustav must know.
