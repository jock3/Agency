---
name: code
description: "One coding workflow for writing, fixing and reviewing code in any project: plan → build → verify → review/QA → release → ship check. Use when the user asks to code, build a feature, fix a bug, refactor, change the database/Supabase (tables, RLS, migrations), deploy or push, 'koda', 'bygg', 'fixa buggen', 'deploya', 'pusha', 'granska koden', 'review PR/diff/commit', or asks 'is this ready to ship / launch', 'är appen säker', 'kan vi lansera'. Not for visual UI design (use design) or accessibility audits (use accessibility)."
argument-hint: "[build | fix | review | ship] [target]"
---

# code

One flow, sized to the task: **plan → build → verify → review/QA → release → ship check.** Merged from Superpowers, Karpathy guidelines, Ponytail, Matt Pocock's skills and Condom (see `SOURCES.md`). The always-on rules live in `~/.claude/CLAUDE.md`; this skill is the process around them.

Load only the file the step needs.

## Rules that override everything

1. **The project wins.** The project's CLAUDE.md, memory and existing conventions beat this skill. If a project says "push straight to main", do not add confirmation gates.
2. **Gustav does not read code.** Every plan, result and review is explained in plain Swedish: what changed, what it means for the user, what is risky. Show screenshots or command output as proof, not diffs. Ask for OK before big rebuilds, not before small fixes.
3. **Evidence before claims.** Nothing is "done", "fixed" or "passing" until it was run in this session (`verify.md`).
4. **Smallest complete change.** Least new code that fully solves the task, including the callers and tests it breaks (`floor.md`).

## Size the flow

| Task | Flow |
|---|---|
| Trivial (typo, one-liner, config value) | build → verify |
| Normal (feature, bug, refactor) | short plan → build → verify → review |
| Big (new app/module, 3+ files, data model, RLS/auth, payments) | plan + OK from Gustav → build in steps → verify each step → review → QA |
| Going live, taking payments, collecting user data | add the ship check |

## 1. Plan

Read the code the task touches first. Then state in a few lines: what you will change, where, how you will check it worked (`1. step → check`). Name assumptions; if two readings are plausible, ask. For big or fuzzy work, the `architect` agent can draft the plan. No design docs or plan files in the repo unless asked.

## 2. Build

Read `floor.md` before the first edit. Reuse what the repo has. Bug fix: read `debug.md` first, find the root cause, then fix it once in the shared code. Anything touching Supabase or the database (tables, RLS, auth, keys, migrations): read `supabase.md` first. Project without git: read the backup rule in `deploy.md` before the first edit.

## 3. Verify

Read `verify.md`. Run the tests, typecheck, build, or the app itself, and read the output. New non-trivial logic gets one small test that would fail if it broke. Use the `test-runner` agent for noisy suites, `test-engineer` to write missing tests, `/run` to see the change in the real app.

## 4. Review / QA

Read `review.md` when asked to review, and before calling a normal or big task done. Built-ins do the heavy lifting: `/code-review` (bugs), `/simplify` (cleanup), `code-reviewer` agent, `qa-engineer` agent (clicks through the running app), `design-reviewer` for UI, the `accessibility` skill for WCAG.

## 5. Release

Before pushing or deploying, read `deploy.md`: how this project goes live, check the live site after, how to roll back, secrets.

## 6. Ship check

Before launch, payments, sign-ups or storing personal data: read `ship/GUIDE.md` (Condom: hacked or sued) and run `/security-review` on the branch. Paths in GUIDE.md are relative to `ship/`. Users are in Sweden/EU, so GDPR and EU cookie rules apply from the first user; do not let the US-threshold logic in GUIDE.md wave them through. Audit is read-only until Gustav says fix. Never print a secret. Never commit `CONDOM-REPORT.md` (it lists open holes); add it to `.gitignore` if the repo has one.

## Files

- `floor.md` — build rules (minimal change, scope, what never to cut)
- `verify.md` — evidence gate before any "done"
- `debug.md` — feedback loop and root cause before fixing
- `review.md` — review procedure and plain-Swedish report format
- `supabase.md` — shared-database rules, RLS, migrations, verify policies; official Supabase guidance bundled in `supabase/`
- `deploy.md` — backups for git-less projects, release steps, live check, rollback, secrets
- `ship/` — Condom bundled unmodified (GUIDE.md, references, report template)
- `SOURCES.md`, `licenses/` — credits, conflict decisions, license texts
