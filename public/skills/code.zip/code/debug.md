# Debug: root cause before fix

No fix before the cause is found. A symptom patch is a failed fix.

## 1. Build a feedback loop (the core of the job)

Get a fast pass/fail signal that goes red on this exact bug. Pick the first that fits:

1. A failing test at the level that reaches the bug (unit, integration, e2e).
2. A curl or HTTP script against the running dev server.
3. A CLI run with a fixed input, compared to known-good output.
4. A Playwright script that drives the UI and checks DOM, console or network.
5. A saved real request or payload, replayed through the code path.
6. A small harness that calls just the broken path with mocked dependencies.
7. For "sometimes wrong": many random inputs until it fails.
8. Appeared between two versions: automate the check and `git bisect run` it.

Make the loop fast and deterministic. If no loop is possible, say so and what would make one possible.

## 2. Reproduce and shrink

Read the full error and stack trace. Reproduce it reliably. Check recent changes (`git log`, `git diff`). Shrink the input to the smallest case that still fails.

## 3. Hypotheses

List 2–4 ranked causes, each with what would prove or disprove it. Show the list to Gustav if they are around; they may know "we just changed X". Test one hypothesis at a time with the smallest possible change.

## 4. Instrument

Debugger or REPL first. Otherwise targeted logs at the boundaries that separate the hypotheses, tagged with a unique prefix (`[DEBUG-a4f2]`) so they can all be removed with one search. Never "log everything". Performance bug: measure a baseline first, then bisect.

## 5. Fix and lock it

Write the failing test or check from step 1 into the suite, make one fix at the root, watch the check go green, run the full suite, remove the debug logs.

## Stop rules

- Two fixes failed: go back to step 1, the loop or the hypothesis is wrong.
- Three fixes failed, or each fix surfaces a new problem elsewhere: stop and question the design. Tell Gustav in plain words before trying more.
- Truly no root cause after a real investigation: add handling (retry, timeout, clear error message) and logging, and say that it is a workaround.
- The `debugger` agent can run this procedure when the cause is not obvious.
